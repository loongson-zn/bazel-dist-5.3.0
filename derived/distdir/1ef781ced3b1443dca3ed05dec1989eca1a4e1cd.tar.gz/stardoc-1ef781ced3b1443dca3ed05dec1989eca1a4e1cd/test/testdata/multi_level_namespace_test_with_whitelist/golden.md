<!-- Generated with Stardoc: http://skydoc.bazel.build -->

<a id="#my_namespace.min"></a>

## my_namespace.min

<pre>
my_namespace.min(<a href="#my_namespace.min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="my_namespace.min-integers"></a>integers |  <p align="center"> - </p>   |  none |


<a id="#my_namespace.math.min"></a>

## my_namespace.math.min

<pre>
my_namespace.math.min(<a href="#my_namespace.math.min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="my_namespace.math.min-integers"></a>integers |  <p align="center"> - </p>   |  none |


<a id="#other_namespace.foo.nothing"></a>

## other_namespace.foo.nothing

<pre>
other_namespace.foo.nothing()
</pre>

This function does nothing.

**PARAMETERS**



