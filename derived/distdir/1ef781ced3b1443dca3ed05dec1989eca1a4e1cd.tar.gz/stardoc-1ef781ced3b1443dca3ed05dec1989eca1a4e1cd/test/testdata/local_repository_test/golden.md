<!-- Generated with Stardoc: http://skydoc.bazel.build -->

<a id="#min"></a>

## min

<pre>
min(<a href="#min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="min-integers"></a>integers |  A list of integers. Must not be empty.   |  none |


