<!-- Generated with Stardoc: http://skydoc.bazel.build -->

<a id="#MyFooInfo"></a>

## MyFooInfo

<pre>
MyFooInfo(<a href="#MyFooInfo-bar">bar</a>, <a href="#MyFooInfo-baz">baz</a>)
</pre>

Stores information about a foo.

**FIELDS**


| Name  | Description |
| :------------- | :------------- |
| <a id="MyFooInfo-bar"></a>bar |  (Undocumented)    |
| <a id="MyFooInfo-baz"></a>baz |  (Undocumented)    |


<a id="#MyPoorlyDocumentedInfo"></a>

## MyPoorlyDocumentedInfo

<pre>
MyPoorlyDocumentedInfo()
</pre>



**FIELDS**



<a id="#MyVeryDocumentedInfo"></a>

## MyVeryDocumentedInfo

<pre>
MyVeryDocumentedInfo(<a href="#MyVeryDocumentedInfo-favorite_food">favorite_food</a>, <a href="#MyVeryDocumentedInfo-favorite_color">favorite_color</a>)
</pre>


A provider with some really neat documentation.
Look on my works, ye mighty, and despair!


**FIELDS**


| Name  | Description |
| :------------- | :------------- |
| <a id="MyVeryDocumentedInfo-favorite_food"></a>favorite_food |  A string representing my favorite food    |
| <a id="MyVeryDocumentedInfo-favorite_color"></a>favorite_color |  A string representing my favorite color    |


