<!-- Generated with Stardoc: http://skydoc.bazel.build -->

<a id="#my_namespace.min"></a>

## my_namespace.min

<pre>
my_namespace.min(<a href="#my_namespace.min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="my_namespace.min-integers"></a>integers |  A list of integers. Must not be empty.   |  none |


<a id="#my_namespace.math.min"></a>

## my_namespace.math.min

<pre>
my_namespace.math.min(<a href="#my_namespace.math.min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="my_namespace.math.min-integers"></a>integers |  A list of integers. Must not be empty.   |  none |


<a id="#my_namespace.foo.bar.baz"></a>

## my_namespace.foo.bar.baz

<pre>
my_namespace.foo.bar.baz()
</pre>

This function does nothing.

**PARAMETERS**



<a id="#my_namespace.one.two.min"></a>

## my_namespace.one.two.min

<pre>
my_namespace.one.two.min(<a href="#my_namespace.one.two.min-integers">integers</a>)
</pre>

Returns the minimum of given elements.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="my_namespace.one.two.min-integers"></a>integers |  A list of integers. Must not be empty.   |  none |


<a id="#my_namespace.one.three.does_nothing"></a>

## my_namespace.one.three.does_nothing

<pre>
my_namespace.one.three.does_nothing()
</pre>

This function does nothing.

**PARAMETERS**



